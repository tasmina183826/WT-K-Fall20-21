

<!DOCTYPE HTML>  
<html>
<head>
</head>
<body>  



<h2>PHP Form Validation Example</h2>
<form action="LabExam.php" method="post" enctype="multipart/form-data">
University: <input type="text" name="university">
  <br>  
  Degree: <input type="text" name="degree">
  <br>
  Major: <input type="major" name="major">
  <br>
 
  Results: <input type="text" name="results">
  <br>
Passing Year:
  <input type="date" name="yearpassed">
 
 
  <a href="db.php">Submit  </a>
  <h2>Do You Want To <a href="logout.php">LogOut</a></h2>
</form>
</body>
</html>
